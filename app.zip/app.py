import os
import socket
from flask import Flask, jsonify
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient

app = Flask(__name__)

ACCOUNT = os.getenv("AZURE_STORAGE_ACCOUNT_NAME")
CONTAINER = os.getenv("AZURE_STORAGE_CONTAINER_NAME", "appdata")
BLOB_NAME = os.getenv("AZURE_STORAGE_BLOB_NAME", "hello.txt")


def _blob_host() -> str:
    if not ACCOUNT:
        raise RuntimeError("Missing AZURE_STORAGE_ACCOUNT_NAME app setting")
    return f"{ACCOUNT}.blob.core.windows.net"


def _resolve_ip(host: str) -> str:
    return socket.gethostbyname(host)


def _blob_service() -> BlobServiceClient:
    url = f"https://{_blob_host()}"
    cred = DefaultAzureCredential()
    return BlobServiceClient(account_url=url, credential=cred)


@app.get("/")
def root():
    return "OK - App Service is running"


@app.get("/debug/dns")
def debug_dns():
    host = _blob_host()
    ip = _resolve_ip(host)
    return jsonify({"blob_host": host, "resolved_ip": ip})


@app.get("/blob/write")
def write_blob():
    svc = _blob_service()
    container = svc.get_container_client(CONTAINER)

    try:
        container.create_container()
    except Exception:
        pass

    blob = container.get_blob_client(BLOB_NAME)
    blob.upload_blob("Hello from Managed Identity over Private Endpoint.\n", overwrite=True)

    return jsonify({"status": "written", "container": CONTAINER, "blob": BLOB_NAME})


@app.get("/blob/read")
def read_blob():
    svc = _blob_service()
    container = svc.get_container_client(CONTAINER)
    blob = container.get_blob_client(BLOB_NAME)

    data = blob.download_blob().readall().decode("utf-8", errors="replace")
    return jsonify({"status": "read", "content": data})
